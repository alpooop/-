from ALPOP import BOTLOG, BOTLOG_CHATID, ALPOP

from ..Config import Config
from ..core.inlinebot import *
